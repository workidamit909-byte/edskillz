# Overview

DataFuture Academy is a modern educational platform focused on Data Science, Data Analytics, and Machine Learning career upskilling. The application is built as a Single Page Application (SPA) with a futuristic, neon-accented design featuring 3D animations, interactive components, and a pay-after-placement business model. The platform provides course recommendations, student portals, success stories, and comprehensive learning management features.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend uses React with TypeScript, built on Vite for fast development and optimized builds. The application follows a component-based architecture with shadcn/ui components for consistent design.

**Key Design Decisions:**
- **React + TypeScript**: Provides type safety and modern development experience
- **Vite**: Fast build tool with hot module replacement for development
- **Tailwind CSS**: Utility-first CSS framework with custom theme variables for the futuristic design
- **Wouter**: Lightweight routing library for client-side navigation
- **React Query**: Data fetching and state management for server interactions

## Backend Architecture
The backend is built with Express.js and follows a RESTful API pattern with authentication middleware.

**Key Design Decisions:**
- **Express.js**: Node.js web framework for handling HTTP requests
- **Modular routing**: Separate route handlers for different API endpoints
- **Middleware pattern**: Authentication, logging, and error handling through middleware
- **File upload support**: Multer integration for resume uploads with validation

## Database Layer
Uses Drizzle ORM with PostgreSQL for type-safe database operations.

**Key Design Decisions:**
- **Drizzle ORM**: Type-safe SQL query builder with schema-first approach
- **PostgreSQL**: Robust relational database with JSON support
- **Neon Database**: Serverless PostgreSQL for scalable cloud deployment
- **Schema-driven design**: Centralized schema definition in `shared/schema.ts`

## Authentication System
Implements Replit's OpenID Connect authentication with session management.

**Key Design Decisions:**
- **OpenID Connect**: Standards-based authentication flow
- **Session storage**: PostgreSQL-backed sessions with connect-pg-simple
- **Passport.js**: Authentication middleware for Express
- **Secure cookies**: HTTPOnly, secure cookies for session management

## State Management
Uses React Query for server state and React Context for client-side theme management.

**Key Design Decisions:**
- **React Query**: Caching, synchronization, and background updates for server data
- **Context API**: Theme provider for dark/light mode switching
- **Custom hooks**: Encapsulated logic for authentication and data fetching

## File Architecture
- `/client`: Frontend React application with components, pages, and utilities
- `/server`: Backend Express server with routes, database, and authentication
- `/shared`: Common TypeScript types and database schema
- Component organization follows domain-driven design with UI components separated

## Styling and Design
Implements a futuristic theme with glassmorphism effects and 3D animations.

**Key Design Decisions:**
- **CSS Variables**: Dynamic theming support for dark/light modes
- **Glassmorphism**: Backdrop blur and transparency effects
- **Neon accents**: Cyan/purple gradient color scheme
- **Responsive design**: Mobile-first approach with Tailwind breakpoints

# External Dependencies

## Database
- **Neon Database**: Serverless PostgreSQL database with connection pooling
- **Drizzle Kit**: Database migration and schema management tools

## Authentication
- **Replit Auth**: OpenID Connect provider for user authentication
- **Passport.js**: Authentication middleware and strategy management

## UI Framework
- **Radix UI**: Headless, accessible UI primitives for complex components
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography

## File Storage
- **Multer**: Middleware for handling multipart/form-data and file uploads
- Local file storage with potential for cloud integration (AWS S3/Cloudinary)

## Development Tools
- **TypeScript**: Static type checking and enhanced developer experience
- **Vite**: Build tool with fast HMR and optimized production builds
- **ESBuild**: Fast JavaScript bundler for server-side code

## Monitoring and Development
- **Replit integration**: Development environment with live preview and debugging
- **Custom error handling**: Structured error responses and logging
- **Development middleware**: Runtime error overlay and source mapping