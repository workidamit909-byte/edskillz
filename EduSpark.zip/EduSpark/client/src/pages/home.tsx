import { useAuth } from "@/hooks/useAuth";
import { QuotesHeader } from "@/components/QuotesHeader";
import { Navigation } from "@/components/Navigation";
import { Hero3D } from "@/components/Hero3D";
import { CourseSection } from "@/components/CourseSection";
import { StudentPortal } from "@/components/StudentPortal";
import { ChatWidget } from "@/components/ChatWidget";
import { JobTicker } from "@/components/JobTicker";

export default function Home() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <QuotesHeader />
      <Navigation />
      <section className="min-h-screen hero-3d neural-network relative overflow-hidden pt-28 pb-16">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
              Welcome back, 
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent animate-glow">
                {user?.firstName || "Student"}
              </span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Continue your journey in Data Science and AI. Your future starts here.
            </p>
          </div>
        </div>
      </section>
      <CourseSection />
      <StudentPortal />
      <ChatWidget />
      <JobTicker />
    </div>
  );
}
