import { QuotesHeader } from "@/components/QuotesHeader";
import { Navigation } from "@/components/Navigation";
import { Hero3D } from "@/components/Hero3D";
import { CourseSection } from "@/components/CourseSection";
import { PricingSection } from "@/components/PricingSection";
import { StudentPortal } from "@/components/StudentPortal";
import { SuccessStories } from "@/components/SuccessStories";
import { ContactSection } from "@/components/ContactSection";
import { ChatWidget } from "@/components/ChatWidget";
import { JobTicker } from "@/components/JobTicker";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <QuotesHeader />
      <Navigation />
      <Hero3D />
      <CourseSection />
      <PricingSection />
      <StudentPortal />
      <SuccessStories />
      <ContactSection />
      <ChatWidget />
      <JobTicker />
    </div>
  );
}
