import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Flag, MapPin } from "lucide-react";

interface ContactForm {
  firstName: string;
  lastName: string;
  email: string;
  interestArea: string;
  message: string;
}

export function ContactSection() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<ContactForm>({
    firstName: "",
    lastName: "",
    email: "",
    interestArea: "",
    message: "",
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactForm) => {
      return await apiRequest('POST', '/api/contact', data);
    },
    onSuccess: () => {
      toast({
        title: "Message sent!",
        description: "We'll get back to you within 24 hours.",
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        interestArea: "",
        message: "",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.firstName && formData.lastName && formData.email && formData.interestArea && formData.message) {
      contactMutation.mutate(formData);
    } else {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
    }
  };

  const handleInputChange = (field: keyof ContactForm) => (value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const offices = [
    {
      region: "United States HQ",
      icon: Flag,
      address: "1234 Innovation Drive",
      city: "San Francisco, CA 94105",
      phone: "+1 (555) 123-4567",
      email: "usa@datafuture.academy",
      imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.2193!2d-122.419906!3d37.774929!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzfCsDQ2JzI5LjciTiAxMjLCsDI1JzExLjciVw!5e0!3m2!1sen!2sus!4v1234567890123",
    },
    {
      region: "United Kingdom",
      icon: Flag,
      address: "Level 15, The Shard",
      city: "London SE1 9SG, UK",
      phone: "+44 20 7946 0958",
      email: "uk@datafuture.academy",
      imageUrl: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2483.2810!2d-0.086520!3d51.504872!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNTHCsDMwJzE3LjUiTiAwwrAwNScxMS41Ilc!5e0!3m2!1sen!2suk!4v1234567890123",
    },
    {
      region: "Canada",
      icon: MapPin,
      address: "Suite 2800, Bay Adelaide Centre",
      city: "Toronto, ON M5H 4E3",
      phone: "+1 (416) 555-0123",
      email: "canada@datafuture.academy",
      imageUrl: "https://images.unsplash.com/photo-1517935706615-2717063c2225?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
      mapUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2886.8267!2d-79.381773!3d43.647766!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDPCsDM4JzUxLjkiTiA3OcKwMjInNTQuNCJX!5e0!3m2!1sen!2sca!4v1234567890123",
    },
  ];

  return (
    <section id="contact" className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6">
            Global <span className="text-primary">Presence</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Find us across three continents with 24/7 support
          </p>
        </div>

        {/* Office Locations */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {offices.map((office, index) => (
            <Card key={index} className="glass-card">
              <CardContent className="p-0">
                <img 
                  src={office.imageUrl} 
                  alt={`${office.region} office building`}
                  className="w-full h-48 object-cover rounded-t-lg"
                  data-testid={`img-office-${index}`}
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center justify-center">
                    <office.icon className="text-primary mr-2 h-5 w-5" />
                    {office.region}
                  </h3>
                  <div className="space-y-2 text-sm text-muted-foreground mb-4">
                    <p data-testid={`text-address-${index}`}>{office.address}</p>
                    <p data-testid={`text-city-${index}`}>{office.city}</p>
                    <p data-testid={`text-phone-${index}`}>{office.phone}</p>
                    <p data-testid={`text-email-${index}`}>{office.email}</p>
                  </div>
                  <iframe 
                    src={office.mapUrl}
                    width="100%" 
                    height="200" 
                    className="rounded-lg border border-border"
                    style={{ border: 0 }}
                    allowFullScreen 
                    loading="lazy"
                    title={`${office.region} office location map`}
                    data-testid={`map-${index}`}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Form */}
        <Card className="glass-card max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Get In Touch</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => handleInputChange('firstName')(e.target.value)}
                    placeholder="John"
                    required
                    data-testid="input-first-name"
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input
                    id="lastName"
                    value={formData.lastName}
                    onChange={(e) => handleInputChange('lastName')(e.target.value)}
                    placeholder="Doe"
                    required
                    data-testid="input-last-name"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email')(e.target.value)}
                  placeholder="john@example.com"
                  required
                  data-testid="input-email"
                />
              </div>
              
              <div>
                <Label htmlFor="interestArea">Interest Area</Label>
                <Select value={formData.interestArea} onValueChange={handleInputChange('interestArea')}>
                  <SelectTrigger data-testid="select-interest-area">
                    <SelectValue placeholder="Select your area of interest" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Data Analytics">Data Analytics</SelectItem>
                    <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                    <SelectItem value="AI Engineering">AI Engineering</SelectItem>
                    <SelectItem value="Career Consultation">Career Consultation</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => handleInputChange('message')(e.target.value)}
                  placeholder="Tell us about your career goals..."
                  rows={4}
                  required
                  data-testid="textarea-message"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                disabled={contactMutation.isPending}
                data-testid="button-send-message"
              >
                {contactMutation.isPending ? 'Sending...' : 'Send Message'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Footer */}
        <footer className="mt-20 pt-16 border-t border-border">
          <div className="grid lg:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="relative">
                  {/* Main logo container with gradient background */}
                  <div className="w-8 h-8 bg-gradient-to-br from-primary via-secondary to-accent rounded-lg flex items-center justify-center">
                    {/* Brain icon with upward arrow symbolizing growth */}
                    <div className="relative">
                      <i className="fas fa-brain text-sm text-white"></i>
                      {/* Growth arrow overlay */}
                      <div className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-accent rounded-full flex items-center justify-center">
                        <svg className="w-1 h-1 text-white" fill="currentColor" viewBox="0 0 12 12">
                          <path d="M6 2l4 4H8v4H4V6H2l4-4z"/>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col">
                  <span className="text-xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                    SkillForge Academy
                  </span>
                  <span className="text-xs text-muted-foreground font-medium">
                    Transform • Upskill • Succeed
                  </span>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">
                Transforming careers through cutting-edge AI and Data Science education with industry-leading placement rates.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-twitter"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-youtube"></i>
                </a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  <i className="fab fa-instagram"></i>
                </a>
              </div>
            </div>

            <div>
              <h4 className="font-bold mb-4">Courses</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Data Analytics</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Machine Learning</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">AI Engineering</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Deep Learning</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">MLOps</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Student Portal</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Career Services</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Community</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Live Chat</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><a href="#" className="hover:text-primary transition-colors">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Refund Policy</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Cookie Policy</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">GDPR Compliance</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 DataFuture Academy. All rights reserved. | Transforming careers through AI education since 2019.</p>
          </div>
        </footer>
      </div>
    </section>
  );
}
