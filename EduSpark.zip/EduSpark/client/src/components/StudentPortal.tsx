import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Upload, CheckCircle, PlayCircle, LogIn } from "lucide-react";
import type { Enrollment, Resume } from "@shared/schema";

export function StudentPortal() {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [resumeFile, setResumeFile] = useState<File | null>(null);

  const { data: enrollments = [] } = useQuery<Enrollment[]>({
    queryKey: ["/api/enrollments"],
    enabled: isAuthenticated,
  });

  const { data: resumes = [] } = useQuery<Resume[]>({
    queryKey: ["/api/resumes"],
    enabled: isAuthenticated,
  });

  const resumeUploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('resume', file);
      return await apiRequest('POST', '/api/resumes', formData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resumes"] });
      toast({
        title: "Success",
        description: "Resume uploaded successfully!",
      });
      setResumeFile(null);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to upload resume. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleResumeUpload = () => {
    if (resumeFile) {
      resumeUploadMutation.mutate(resumeFile);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
      if (allowedTypes.includes(file.type)) {
        setResumeFile(file);
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload a PDF, DOC, or DOCX file.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <section className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6">
            Student <span className="text-primary">Portal</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Secure authentication and comprehensive learning dashboard
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {!isAuthenticated ? (
              <>
                {/* Login/Registration */}
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle>Access Your Dashboard</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4 mb-6">
                      <Button 
                        variant="outline" 
                        className="w-full flex items-center justify-center bg-white text-gray-800 hover:bg-gray-100"
                        onClick={() => window.location.href = '/api/login'}
                        data-testid="button-google-auth"
                      >
                        <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                          <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                          <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                          <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                          <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                        Continue with Google
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full flex items-center justify-center bg-blue-600 text-white hover:bg-blue-700"
                        onClick={() => window.location.href = '/api/login'}
                        data-testid="button-linkedin-auth"
                      >
                        <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.338 16.338H13.67V12.16c0-.995-.017-2.277-1.387-2.277-1.39 0-1.601 1.086-1.601 2.207v4.248H8.014v-8.59h2.559v1.174h.037c.356-.675 1.227-1.387 2.526-1.387 2.703 0 3.203 1.778 3.203 4.092v4.711zM5.005 6.575a1.548 1.548 0 11-.003-3.096 1.548 1.548 0 01.003 3.096zm-1.337 9.763H6.34v-8.59H3.667v8.59zM17.668 1H2.328C1.595 1 1 1.581 1 2.298v15.403C1 18.418 1.595 19 2.328 19h15.34c.734 0 1.332-.582 1.332-1.299V2.298C19 1.581 18.402 1 17.668 1z" clipRule="evenodd"/>
                        </svg>
                        Continue with LinkedIn
                      </Button>
                    </div>

                    <div className="relative mb-6">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-border"></div>
                      </div>
                      <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-card text-muted-foreground">Or sign in directly</span>
                      </div>
                    </div>

                    <div className="text-center">
                      <Button 
                        onClick={() => window.location.href = '/api/login'}
                        className="w-full"
                        data-testid="button-sign-in-direct"
                      >
                        <LogIn className="mr-2 h-4 w-4" />
                        Sign In with Replit
                      </Button>
                    </div>

                    <p className="text-center text-sm text-muted-foreground mt-4">
                      New to DataFuture Academy? <a href="/api/login" className="text-primary hover:underline">Sign up here</a>
                    </p>
                  </CardContent>
                </Card>

                {/* Dashboard Preview */}
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle>Your Learning Dashboard Preview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Course Progress</span>
                          <span className="text-sm text-muted-foreground">Sign in to view</span>
                        </div>
                        <Progress value={0} className="h-2" />
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center p-3 bg-muted/50 rounded-lg border border-border/50 opacity-50">
                          <PlayCircle className="text-primary mr-3 h-5 w-5" />
                          <div className="flex-1">
                            <div className="font-semibold">Machine Learning Fundamentals</div>
                            <div className="text-sm text-muted-foreground">Sign in to access</div>
                          </div>
                        </div>
                        
                        <div className="flex items-center p-3 bg-muted/50 rounded-lg border border-border/50 opacity-50">
                          <CheckCircle className="text-accent mr-3 h-5 w-5" />
                          <div className="flex-1">
                            <div className="font-semibold">Python for Data Science</div>
                            <div className="text-sm text-muted-foreground">Sign in to view progress</div>
                          </div>
                        </div>
                      </div>

                      <div className="border-2 border-dashed border-border rounded-lg p-6 text-center opacity-50">
                        <Upload className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                        <p className="text-sm text-muted-foreground mb-2">Resume upload available after sign in</p>
                        <p className="text-xs text-muted-foreground">Accepts .pdf, .doc, .docx files</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : (
              <>
                {/* Authenticated Dashboard */}
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle>Welcome back, {user?.firstName || "Student"}!</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {/* Progress Overview */}
                    {enrollments.length > 0 ? (
                      <div className="mb-6">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Overall Progress</span>
                          <span className="text-sm text-muted-foreground">
                            {enrollments.reduce((acc, e) => acc + (e.progress || 0), 0) / enrollments.length}% Complete
                          </span>
                        </div>
                        <Progress 
                          value={enrollments.reduce((acc, e) => acc + (e.progress || 0), 0) / enrollments.length} 
                          className="h-2" 
                        />
                      </div>
                    ) : (
                      <div className="mb-6 p-4 bg-muted/20 rounded-lg text-center">
                        <p className="text-muted-foreground">No enrollments yet. Browse courses to get started!</p>
                      </div>
                    )}

                    {/* Current Modules */}
                    <div className="space-y-4 mb-6">
                      {enrollments.length > 0 ? (
                        enrollments.map((enrollment, index) => (
                          <div key={enrollment.id} className={`flex items-center p-3 rounded-lg border ${
                            (enrollment.progress || 0) === 100 
                              ? 'bg-accent/10 border-accent/20' 
                              : 'bg-primary/10 border-primary/20'
                          }`}>
                            {(enrollment.progress || 0) === 100 ? (
                              <CheckCircle className="text-accent mr-3 h-5 w-5" />
                            ) : (
                              <PlayCircle className="text-primary mr-3 h-5 w-5" />
                            )}
                            <div className="flex-1">
                              <div className="font-semibold">Course {index + 1}</div>
                              <div className="text-sm text-muted-foreground">
                                Progress: {enrollment.progress || 0}%
                              </div>
                            </div>
                            <div className={`text-sm font-semibold ${
                              (enrollment.progress || 0) === 100 ? 'text-accent' : 'text-primary'
                            }`}>
                              {(enrollment.progress || 0) === 100 ? 'Completed' : 'In Progress'}
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-center text-muted-foreground">
                          <PlayCircle className="mx-auto h-12 w-12 mb-2 opacity-50" />
                          <p>Start your first course to see progress here</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Resume Upload */}
                <Card className="glass-card">
                  <CardHeader>
                    <CardTitle>Resume Management</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {/* Previous Resumes */}
                    {resumes.length > 0 && (
                      <div className="mb-6">
                        <h4 className="font-semibold mb-3">Uploaded Resumes</h4>
                        <div className="space-y-2">
                          {resumes.map((resume) => (
                            <div key={resume.id} className="flex items-center justify-between p-2 bg-muted/20 rounded-lg">
                              <span className="text-sm">{resume.fileName}</span>
                              <span className="text-xs text-muted-foreground">
                                {new Date(resume.uploadedAt!).toLocaleDateString()}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Upload New Resume */}
                    <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                      <Upload className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground mb-2">
                        {resumes.length > 0 ? 'Upload a new resume' : 'Upload your resume for career services'}
                      </p>
                      <p className="text-xs text-muted-foreground mb-4">Accepts .pdf, .doc, .docx files</p>
                      
                      <div className="space-y-3">
                        <div>
                          <Label htmlFor="resume-upload" className="sr-only">Choose resume file</Label>
                          <Input
                            id="resume-upload"
                            type="file"
                            accept=".pdf,.doc,.docx"
                            onChange={handleFileChange}
                            className="max-w-xs mx-auto"
                            data-testid="input-resume-upload"
                          />
                        </div>
                        
                        {resumeFile && (
                          <div className="text-sm text-muted-foreground">
                            Selected: {resumeFile.name}
                          </div>
                        )}
                        
                        <Button 
                          onClick={handleResumeUpload}
                          disabled={!resumeFile || resumeUploadMutation.isPending}
                          data-testid="button-upload-resume"
                        >
                          {resumeUploadMutation.isPending ? 'Uploading...' : 'Upload Resume'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
