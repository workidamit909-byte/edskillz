import { useTheme } from "@/components/ThemeProvider";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Sun, Moon, Brain } from "lucide-react";

export function Navigation() {
  const { theme, toggleTheme } = useTheme();
  const { isAuthenticated, user } = useAuth();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Theme Toggle */}
      <button 
        onClick={toggleTheme}
        className="fixed top-4 right-4 z-50 p-3 bg-card/80 backdrop-blur-sm border border-border rounded-full hover:bg-primary/20 transition-all duration-300" 
        aria-label="Toggle theme"
        data-testid="button-theme-toggle"
      >
        {theme === "light" ? (
          <Moon className="h-5 w-5 text-primary" />
        ) : (
          <Sun className="h-5 w-5 text-yellow-400" />
        )}
      </button>

      {/* Main Navigation */}
      <nav className="fixed top-12 left-0 right-0 z-40 bg-card/80 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              {/* Enhanced Logo */}
              <div className="relative">
                {/* Main logo container with gradient background */}
                <div className="w-10 h-10 bg-gradient-to-br from-primary via-secondary to-accent rounded-xl flex items-center justify-center shadow-lg animate-pulse-neon">
                  {/* Brain icon with upward arrow symbolizing growth */}
                  <div className="relative">
                    <Brain className="h-5 w-5 text-white animate-glow" />
                    {/* Growth arrow overlay */}
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full flex items-center justify-center">
                      <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 12 12">
                        <path d="M6 2l4 4H8v4H4V6H2l4-4z"/>
                      </svg>
                    </div>
                  </div>
                </div>
                {/* Animated skill rings */}
                <div className="absolute -inset-1 rounded-full border border-primary/30 animate-ping" />
                <div className="absolute -inset-2 rounded-full border border-secondary/20 animate-ping" style={{animationDelay: '0.5s'}} />
              </div>
              
              {/* Enhanced Brand Name */}
              <div className="flex flex-col">
                <span className="text-xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
                  SkillForge Academy
                </span>
                <span className="text-xs text-muted-foreground font-medium tracking-wide">
                  Transform • Upskill • Succeed
                </span>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('home')} 
                className="hover:text-primary transition-colors"
                data-testid="link-home"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('courses')} 
                className="hover:text-primary transition-colors"
                data-testid="link-courses"
              >
                Courses
              </button>
              {!isAuthenticated && (
                <>
                  <button 
                    onClick={() => scrollToSection('pricing')} 
                    className="hover:text-primary transition-colors"
                    data-testid="link-pricing"
                  >
                    Pricing
                  </button>
                  <button 
                    onClick={() => scrollToSection('success')} 
                    className="hover:text-primary transition-colors"
                    data-testid="link-success"
                  >
                    Success Stories
                  </button>
                </>
              )}
              <button 
                onClick={() => scrollToSection('contact')} 
                className="hover:text-primary transition-colors"
                data-testid="link-contact"
              >
                Contact
              </button>
            </div>

            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <>
                  <span className="text-sm text-muted-foreground">
                    Welcome, {user?.firstName || "Student"}
                  </span>
                  <Button 
                    variant="outline" 
                    onClick={() => window.location.href = '/api/logout'}
                    data-testid="button-logout"
                  >
                    Sign Out
                  </Button>
                </>
              ) : (
                <>
                  <Button 
                    variant="outline" 
                    onClick={() => window.location.href = '/api/login'}
                    data-testid="button-signin"
                  >
                    Sign In
                  </Button>
                  <Button 
                    onClick={() => window.location.href = '/api/login'}
                    className="animate-pulse-neon"
                    data-testid="button-get-started"
                  >
                    Get Started
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>
    </>
  );
}
