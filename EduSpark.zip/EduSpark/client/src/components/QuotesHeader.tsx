export function QuotesHeader() {
  const quotes = [
    "The development of AI will transform every industry and create opportunities we can't yet imagine. - Geoffrey Hinton",
    "Machine learning will automate automation itself. - Andrew Ng",
    "AI is the new electricity. It will transform every industry. - Yoshua Bengio",
    "The future belongs to organizations that can turn data into insights and insights into action. - Sundar Pichai"
  ];

  return (
    <div className="fixed top-0 left-0 right-0 z-40 bg-card/90 backdrop-blur-sm border-b border-border py-2 overflow-hidden">
      <div className="ticker whitespace-nowrap">
        <span className="inline-block px-8 text-sm text-muted-foreground">
          <i className="fas fa-quote-left mr-2"></i>
          {quotes.map((quote, index) => (
            <span key={index}>
              {quote}
              {index < quotes.length - 1 && <span className="mx-8">•</span>}
            </span>
          ))}
        </span>
      </div>
    </div>
  );
}
