import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Flag, MapPin } from "lucide-react";
import type { SuccessStory } from "@shared/schema";

export function SuccessStories() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const { data: stories = [] } = useQuery<SuccessStory[]>({
    queryKey: ["/api/success-stories"],
  });

  // Default stories for demonstration
  const defaultStories = [
    {
      id: "1",
      name: "Sarah Chen",
      currentRole: "Data Scientist",
      company: "Google",
      newSalary: "$145K",
      salaryIncrease: 280,
      testimonial: "The comprehensive curriculum and mentorship program transformed my career completely. I went from a retail manager to a data scientist at Google in just 8 months!",
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    },
    {
      id: "2",
      name: "Marcus Johnson",
      currentRole: "ML Engineer",
      company: "Microsoft",
      newSalary: "$138K",
      salaryIncrease: 320,
      testimonial: "The hands-on projects and real-world applications made all the difference. I'm now building AI systems that impact millions of users daily.",
      imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    },
  ];

  const displayStories = stories.length > 0 ? stories : defaultStories;
  const totalSlides = displayStories.length;

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % totalSlides);
    }, 8000);

    return () => clearInterval(interval);
  }, [totalSlides]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const salaryData = [
    {
      region: "United States",
      icon: Flag,
      roles: [
        { title: "Data Analyst", salary: "$85K" },
        { title: "ML Engineer", salary: "$130K" },
        { title: "AI Engineer", salary: "$155K" },
      ],
    },
    {
      region: "United Kingdom", 
      icon: Flag,
      roles: [
        { title: "Data Analyst", salary: "£55K" },
        { title: "ML Engineer", salary: "£85K" },
        { title: "AI Engineer", salary: "£95K" },
      ],
    },
    {
      region: "Canada",
      icon: MapPin,
      roles: [
        { title: "Data Analyst", salary: "C$75K" },
        { title: "ML Engineer", salary: "C$110K" },
        { title: "AI Engineer", salary: "C$125K" },
      ],
    },
  ];

  return (
    <section id="success" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6">
            Success <span className="text-accent">Stories</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Real graduates, real transformations, real career growth
          </p>
        </div>

        {/* Salary Data Visualization */}
        <Card className="glass-card mb-16">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold mb-6 text-center">Average Salary by Region</h3>
            <div className="grid md:grid-cols-3 gap-8">
              {salaryData.map((region, index) => (
                <div key={index} className="text-center">
                  <div className="mb-4">
                    <region.icon className="mx-auto h-10 w-10 text-primary mb-2" />
                    <h4 className="text-xl font-bold">{region.region}</h4>
                  </div>
                  <div className="space-y-2">
                    {region.roles.map((role, roleIndex) => (
                      <div key={roleIndex} className="flex justify-between">
                        <span className="text-sm">{role.title}</span>
                        <span className={`font-semibold ${
                          roleIndex === 0 ? 'text-primary' : 
                          roleIndex === 1 ? 'text-secondary' : 'text-accent'
                        }`}>
                          {role.salary}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Success Stories Carousel */}
        <div className="relative">
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-500"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
              data-testid="testimonial-slider"
            >
              {displayStories.map((story, index) => (
                <div key={story.id} className="w-full flex-shrink-0">
                  <div className="grid lg:grid-cols-2 gap-8 items-center">
                    <Card className="glass-card">
                      <CardContent className="p-8">
                        <div className="flex items-center mb-4">
                          <img 
                            src={story.imageUrl} 
                            alt={`Professional headshot of ${story.name}`}
                            className="w-16 h-16 rounded-full object-cover mr-4"
                            data-testid={`img-testimonial-${index}`}
                          />
                          <div>
                            <div className="font-bold" data-testid={`text-name-${index}`}>
                              {story.name}
                            </div>
                            <div className="text-sm text-muted-foreground" data-testid={`text-role-${index}`}>
                              {story.currentRole} @ {story.company}
                            </div>
                          </div>
                        </div>
                        <p className="text-lg italic mb-4" data-testid={`text-testimonial-${index}`}>
                          "{story.testimonial}"
                        </p>
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div>
                            <div className="text-2xl font-bold text-primary" data-testid={`text-salary-${index}`}>
                              {story.newSalary}
                            </div>
                            <div className="text-sm text-muted-foreground">New Salary</div>
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-accent" data-testid={`text-increase-${index}`}>
                              {story.salaryIncrease}%
                            </div>
                            <div className="text-sm text-muted-foreground">Salary Increase</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    <div>
                      <img 
                        src={index === 0 
                          ? "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                          : "https://images.unsplash.com/photo-1555949963-aa79dcee981c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                        }
                        alt={index === 0 
                          ? "Modern tech office with multiple screens showing data analytics dashboards"
                          : "Software developer working on AI models with neural network visualizations"
                        }
                        className="rounded-2xl shadow-2xl w-full"
                        data-testid={`img-office-${index}`}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Carousel Controls */}
          <div className="flex justify-center mt-8 space-x-4">
            <Button 
              variant="outline" 
              size="icon"
              onClick={prevSlide}
              className="rounded-full"
              data-testid="button-prev-testimonial"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button 
              variant="outline" 
              size="icon"
              onClick={nextSlide}
              className="rounded-full"
              data-testid="button-next-testimonial"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {/* Slide Indicators */}
          <div className="flex justify-center mt-4 space-x-2">
            {displayStories.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-primary' : 'bg-muted'
                }`}
                data-testid={`indicator-${index}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
