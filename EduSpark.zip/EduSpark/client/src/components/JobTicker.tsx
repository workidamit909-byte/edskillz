import { useQuery } from "@tanstack/react-query";
import { Briefcase } from "lucide-react";
import type { JobListing } from "@shared/schema";

export function JobTicker() {
  const { data: jobs = [] } = useQuery<JobListing[]>({
    queryKey: ["/api/jobs"],
  });

  // Default job listings for demonstration
  const defaultJobs = [
    { id: "1", title: "Senior Data Scientist", company: "Meta", salary: "$165K", region: "USA" },
    { id: "2", title: "ML Engineer", company: "Amazon", salary: "$152K", region: "USA" },
    { id: "3", title: "AI Researcher", company: "OpenAI", salary: "$180K", region: "USA" },
    { id: "4", title: "Data Analyst", company: "Netflix", salary: "$125K", region: "USA" },
    { id: "5", title: "ML Engineer", company: "Google", salary: "$170K", region: "USA" },
    { id: "6", title: "Data Scientist", company: "Microsoft", salary: "$158K", region: "USA" },
    { id: "7", title: "Lead Data Scientist", company: "DeepMind", salary: "£95K", region: "UK" },
    { id: "8", title: "Senior ML Engineer", company: "BBC", salary: "£78K", region: "UK" },
    { id: "9", title: "AI Product Manager", company: "Revolut", salary: "£85K", region: "UK" },
    { id: "10", title: "Principal Data Scientist", company: "Shopify", salary: "C$145K", region: "Canada" },
    { id: "11", title: "ML Engineer", company: "RBC", salary: "C$115K", region: "Canada" },
    { id: "12", title: "AI Engineer", company: "TD Bank", salary: "C$125K", region: "Canada" },
  ];

  const displayJobs = jobs.length > 0 ? jobs : defaultJobs;

  // Group jobs by region
  const jobsByRegion = displayJobs.reduce((acc, job) => {
    if (!acc[job.region]) {
      acc[job.region] = [];
    }
    acc[job.region].push(job);
    return acc;
  }, {} as Record<string, typeof displayJobs>);

  const formatJobString = (jobs: typeof displayJobs, region: string) => {
    return jobs.map(job => `${job.title} @ ${job.company} - ${job.salary}`).join(' | ');
  };

  const tickerContent = Object.entries(jobsByRegion).map(([region, regionJobs]) => {
    const regionLabel = region === 'USA' ? 'US' : region === 'UK' ? 'UK' : 'Canada';
    return `${regionLabel}: ${formatJobString(regionJobs, region)}`;
  }).join(' • ');

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-card/90 backdrop-blur-sm border-t border-border py-2 overflow-hidden z-30">
      <div className="ticker whitespace-nowrap" data-testid="job-ticker">
        <span className="inline-block px-4 text-sm text-muted-foreground">
          <Briefcase className="inline-block text-primary mr-2 h-4 w-4" />
          <strong>Hot Jobs:</strong> {tickerContent}
        </span>
      </div>
    </div>
  );
}
