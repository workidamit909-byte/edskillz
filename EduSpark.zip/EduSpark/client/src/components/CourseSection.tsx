import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChartLine, Brain, Bot, Sparkles } from "lucide-react";
import type { Course } from "@shared/schema";

export function CourseSection() {
  const { data: courses = [], isLoading } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const courseRecommendations = [
    {
      title: "Data Science Fundamentals",
      description: "Perfect for beginners",
      color: "primary",
      icon: ChartLine,
    },
    {
      title: "Machine Learning Advanced", 
      description: "For experienced professionals",
      color: "secondary",
      icon: Brain,
    },
    {
      title: "AI Engineering Track",
      description: "End-to-end AI solutions", 
      color: "accent",
      icon: Bot,
    },
  ];

  const defaultCourses = [
    {
      id: "1",
      title: "Data Analytics",
      description: "Python, SQL, Tableau",
      duration: "6 months",
      skillLevel: "Beginner",
      averageSalary: "$75K-$95K",
      placementRate: 96,
      icon: ChartLine,
      imageUrl: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    },
    {
      id: "2", 
      title: "Machine Learning",
      description: "Python, TensorFlow, PyTorch",
      duration: "8 months",
      skillLevel: "Intermediate",
      averageSalary: "$110K-$140K",
      placementRate: 94,
      icon: Brain,
      imageUrl: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    },
    {
      id: "3",
      title: "AI Engineering", 
      description: "MLOps, Cloud, Production AI",
      duration: "10 months",
      skillLevel: "Advanced",
      averageSalary: "$130K-$180K",
      placementRate: 92,
      icon: Bot,
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=300",
    },
  ];

  const displayCourses = courses.length > 0 ? courses : defaultCourses;

  return (
    <section id="courses" className="py-20 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6">
            World-Class <span className="text-primary">Curriculum</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Comprehensive programs designed by industry experts from Google, Microsoft, and top universities
          </p>
        </div>

        {/* AI-Powered Course Recommendations */}
        <Card className="glass-card mb-12">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Sparkles className="text-primary mr-3" />
              AI-Powered Course Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">Based on your background and career goals, we recommend:</p>
            <div className="grid md:grid-cols-3 gap-4">
              {courseRecommendations.map((rec, index) => (
                <Card key={index} className={`bg-${rec.color}/10 border border-${rec.color}/20`}>
                  <CardContent className="p-4">
                    <h4 className={`font-semibold text-${rec.color} flex items-center`}>
                      <rec.icon className="mr-2 h-4 w-4" />
                      {rec.title}
                    </h4>
                    <p className="text-sm text-muted-foreground">{rec.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Course Comparison Table */}
        <div className="mb-16 overflow-x-auto">
          <Card className="glass-card">
            <div className="overflow-hidden">
              <div className="bg-primary/20 p-4">
                <h3 className="text-xl font-bold text-center">Course Comparison</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-primary/10">
                    <tr>
                      <th className="p-4 text-left">Course Track</th>
                      <th className="p-4 text-center">Duration</th>
                      <th className="p-4 text-center">Skill Level</th>
                      <th className="p-4 text-center">Avg. Salary</th>
                      <th className="p-4 text-center">Placement Rate</th>
                      <th className="p-4 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayCourses.map((course, index) => {
                      const IconComponent = course.icon || ChartLine;
                      const levelColors = {
                        Beginner: "accent",
                        Intermediate: "secondary", 
                        Advanced: "destructive"
                      };
                      const levelColor = levelColors[course.skillLevel as keyof typeof levelColors] || "muted";
                      
                      return (
                        <tr key={course.id} className="border-b border-border/50">
                          <td className="p-4">
                            <div className="flex items-center">
                              <IconComponent className="text-primary mr-3 h-5 w-5" />
                              <div>
                                <div className="font-semibold">{course.title}</div>
                                <div className="text-sm text-muted-foreground">{course.description}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4 text-center">{course.duration}</td>
                          <td className="p-4 text-center">
                            <Badge variant="secondary" className={`bg-${levelColor}/20 text-${levelColor}`}>
                              {course.skillLevel}
                            </Badge>
                          </td>
                          <td className="p-4 text-center font-semibold text-primary">{course.averageSalary}</td>
                          <td className="p-4 text-center font-semibold text-accent">{course.placementRate}%</td>
                          <td className="p-4 text-center">
                            <Button size="sm" data-testid={`button-enroll-${index}`}>
                              Enroll
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </Card>
        </div>

        {/* Course Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayCourses.map((course, index) => (
            <Card key={course.id} className="glass-card hover:scale-105 transition-all duration-300">
              <CardContent className="p-0">
                <img 
                  src={course.imageUrl} 
                  alt={`${course.title} course preview`}
                  className="w-full h-48 object-cover rounded-t-lg"
                  data-testid={`img-course-${index}`}
                />
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{course.title}</h3>
                  <p className="text-muted-foreground mb-4">{course.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-primary font-semibold">{course.duration}</span>
                    <Button 
                      variant="outline" 
                      className="hover:bg-primary hover:text-primary-foreground"
                      data-testid={`button-learn-more-${index}`}
                    >
                      Learn More
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
