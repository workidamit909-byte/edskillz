import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Bot, User, Sparkles } from "lucide-react";

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hi! I'm here to help you get started with your Data Science journey. What questions do you have?",
      sender: 'ai',
      timestamp: new Date(),
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const sendMessage = () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputMessage,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(inputMessage),
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 1000);

    setInputMessage("");
  };

  const getAIResponse = (userInput: string): string => {
    const lowerInput = userInput.toLowerCase();
    
    if (lowerInput.includes('course') || lowerInput.includes('program')) {
      return "We offer three main tracks: Data Analytics (6 months), Machine Learning (8 months), and AI Engineering (10 months). Each includes hands-on projects and job placement support. Would you like details on any specific track?";
    }
    
    if (lowerInput.includes('price') || lowerInput.includes('cost') || lowerInput.includes('pay')) {
      return "Our pay-after-placement model starts with just $11 registration. You can choose from $199 minimum upfront, $499 partial upfront, or full upfront with 20% discount. The majority is paid only after you land your job!";
    }
    
    if (lowerInput.includes('job') || lowerInput.includes('placement') || lowerInput.includes('career')) {
      return "We have a 94% placement rate with graduates earning $80K-$180K annually. Our career services include resume optimization, interview coaching, and direct connections with 180+ partner companies including Google, Microsoft, and Amazon.";
    }
    
    if (lowerInput.includes('time') || lowerInput.includes('schedule') || lowerInput.includes('duration')) {
      return "Our programs are designed for working professionals with flexible scheduling. Most students dedicate 10-15 hours per week and complete their track within 6-10 months depending on the program chosen.";
    }
    
    return "That's a great question! I'd be happy to connect you with one of our human advisors who can provide detailed information. You can also explore our courses section or schedule a free consultation call. What specific area interests you most?";
  };

  const handleQuickAction = (action: string) => {
    setInputMessage(action);
    sendMessage();
  };

  const quickActions = [
    "Course Info",
    "Pricing",
    "Human Agent"
  ];

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {/* Chat Toggle Button */}
      <Button
        onClick={toggleChat}
        size="lg"
        className="w-16 h-16 rounded-full shadow-lg hover:scale-110 transition-all animate-pulse-neon"
        data-testid="button-chat-toggle"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
      
      {/* Chat Window */}
      {isOpen && (
        <Card className="absolute bottom-20 right-0 w-80 h-96 glass-card border border-border overflow-hidden">
          {/* Chat Header */}
          <CardHeader className="bg-primary text-primary-foreground p-4 flex flex-row items-center justify-between">
            <div className="flex items-center">
              <Bot className="mr-2 h-5 w-5" />
              <span className="font-semibold">AI Support</span>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={toggleChat}
              className="hover:bg-primary/80 rounded p-1 h-8 w-8"
              data-testid="button-chat-close"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          
          {/* Messages Area */}
          <CardContent className="p-4 h-64 overflow-y-auto space-y-3">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={`flex items-start ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.sender === 'ai' && (
                  <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center mr-2 flex-shrink-0">
                    <Bot className="text-primary h-4 w-4" />
                  </div>
                )}
                <div 
                  className={`max-w-[70%] rounded-lg p-3 text-sm ${
                    message.sender === 'user' 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted'
                  }`}
                  data-testid={`message-${message.sender}-${message.id}`}
                >
                  {message.text}
                </div>
                {message.sender === 'user' && (
                  <div className="w-8 h-8 bg-secondary/20 rounded-full flex items-center justify-center ml-2 flex-shrink-0">
                    <User className="text-secondary h-4 w-4" />
                  </div>
                )}
              </div>
            ))}
          </CardContent>
          
          {/* Input Area */}
          <div className="border-t border-border p-4">
            <div className="flex space-x-2 mb-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 text-sm"
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                data-testid="input-chat-message"
              />
              <Button 
                onClick={sendMessage}
                size="sm"
                disabled={!inputMessage.trim()}
                data-testid="button-send-message"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Quick Actions */}
            <div className="flex justify-center space-x-2">
              {quickActions.map((action, index) => (
                <Button
                  key={action}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickAction(action)}
                  className={`text-xs px-3 py-1 ${
                    index === 0 ? 'hover:bg-secondary hover:text-secondary-foreground border-secondary/30 text-secondary' :
                    index === 1 ? 'hover:bg-accent hover:text-accent-foreground border-accent/30 text-accent' :
                    'hover:bg-primary hover:text-primary-foreground border-primary/30 text-primary'
                  }`}
                  data-testid={`button-quick-action-${index}`}
                >
                  {action}
                </Button>
              ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
