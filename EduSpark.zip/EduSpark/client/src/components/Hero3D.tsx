import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Rocket, Play } from "lucide-react";
import { DemoVideoModal } from "./DemoVideoModal";

export function Hero3D() {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);

  useEffect(() => {
    // Create floating particles and geometric shapes
    const createFloatingElements = () => {
      if (!canvasRef.current) return;

      const shapes = [
        { size: 16, delay: 0, color: 'primary' },
        { size: 12, delay: 1, color: 'secondary' },
        { size: 20, delay: 2, color: 'accent' },
        { size: 8, delay: 3, color: 'primary' },
        { size: 14, delay: 4, color: 'secondary' },
      ];

      shapes.forEach((shape, index) => {
        const element = document.createElement('div');
        element.className = `absolute w-${shape.size} h-${shape.size} bg-${shape.color}/20 rounded-lg animate-float`;
        element.style.animationDelay = `${shape.delay}s`;
        
        // Random positioning
        element.style.top = `${Math.random() * 80 + 10}%`;
        element.style.left = `${Math.random() * 80 + 10}%`;
        
        canvasRef.current?.appendChild(element);
      });

      // Create particle effects
      for (let i = 0; i < 10; i++) {
        const particle = document.createElement('div');
        particle.className = 'absolute w-1 h-1 bg-primary rounded-full animate-ping';
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.animationDelay = `${Math.random() * 3}s`;
        
        canvasRef.current?.appendChild(particle);
      }
    };

    createFloatingElements();

    return () => {
      if (canvasRef.current) {
        canvasRef.current.innerHTML = '';
      }
    };
  }, []);

  return (
    <section id="home" className="min-h-screen hero-3d neural-network relative overflow-hidden pt-28 pb-16">
      {/* 3D Background Elements */}
      <div ref={canvasRef} className="absolute inset-0 overflow-hidden" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <div className="lg:w-1/2 mb-12 lg:mb-0">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
              Transform Your Career with
              <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent animate-glow block">
                AI & Data Science
              </span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
              Master cutting-edge skills in Data Science, Machine Learning, and AI with our comprehensive 
              pay-after-placement program. Join thousands of successful graduates now earning $80K-$150K+ annually.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                size="lg" 
                className="px-8 py-4 text-lg animate-pulse-neon"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-start-journey"
              >
                <Rocket className="mr-2 h-5 w-5" />
                Start Your Journey - $11 Only
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="px-8 py-4 text-lg"
                onClick={() => setIsDemoModalOpen(true)}
                data-testid="button-watch-demo"
              >
                <Play className="mr-2 h-5 w-5" />
                Watch Demo
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary" data-testid="stat-graduates">5,847</div>
                <div className="text-sm text-muted-foreground">Graduates Placed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-secondary" data-testid="stat-success-rate">94%</div>
                <div className="text-sm text-muted-foreground">Success Rate</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-accent" data-testid="stat-avg-salary">$127K</div>
                <div className="text-sm text-muted-foreground">Avg. Starting Salary</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary" data-testid="stat-companies">180+</div>
                <div className="text-sm text-muted-foreground">Partner Companies</div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 flex justify-center">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Data scientist working with AI models and analytics" 
                className="rounded-2xl shadow-2xl w-full max-w-lg"
                data-testid="img-hero"
              />
              <div className="absolute -top-4 -right-4 w-24 h-24 glass-card rounded-full flex items-center justify-center animate-rotate-y">
                <i className="fas fa-robot text-2xl text-primary"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Demo Video Modal */}
      <DemoVideoModal 
        isOpen={isDemoModalOpen} 
        onClose={() => setIsDemoModalOpen(false)} 
      />
    </section>
  );
}
