import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Check } from "lucide-react";

export function PricingSection() {
  const [selectedCourse, setSelectedCourse] = useState("data-analytics");
  const [paymentPlan, setPaymentPlan] = useState("minimum");

  const courseDetails = {
    "data-analytics": { basePrice: 5999, duration: "6 months" },
    "machine-learning": { basePrice: 6999, duration: "8 months" },
    "ai-engineering": { basePrice: 7999, duration: "10 months" },
  };

  const calculatePricing = () => {
    const course = courseDetails[selectedCourse as keyof typeof courseDetails];
    let upfront = 199;
    let discount = 0;

    if (paymentPlan === "partial") upfront = 499;
    if (paymentPlan === "full") {
      upfront = course.basePrice * 0.8; // 20% discount
      discount = course.basePrice * 0.2;
    }

    const afterPlacement = paymentPlan === "full" ? 0 : course.basePrice - upfront;
    const total = paymentPlan === "full" ? upfront : course.basePrice;

    return { upfront, afterPlacement, total, discount };
  };

  const pricing = calculatePricing();

  return (
    <section id="pricing" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-6">
            Pay After <span className="text-accent">Placement</span> Model
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Start your career transformation with minimal upfront investment. Pay the majority only after you land your dream job.
          </p>
        </div>

        {/* Interactive Pricing Calculator */}
        <Card className="glass-card max-w-4xl mx-auto mb-16">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Interactive Pricing Calculator</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div>
                <label className="block text-sm font-medium mb-2">Select Your Track</label>
                <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                  <SelectTrigger data-testid="select-course-track">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="data-analytics">Data Analytics - 6 months</SelectItem>
                    <SelectItem value="machine-learning">Machine Learning - 8 months</SelectItem>
                    <SelectItem value="ai-engineering">AI Engineering - 10 months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Payment Plan</label>
                <Select value={paymentPlan} onValueChange={setPaymentPlan}>
                  <SelectTrigger data-testid="select-payment-plan">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minimum">Minimum Upfront ($199)</SelectItem>
                    <SelectItem value="partial">Partial Upfront ($499)</SelectItem>
                    <SelectItem value="full">Full Upfront (20% Discount)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="p-6 bg-primary/10 rounded-lg border border-primary/20">
              <div className="grid md:grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-sm text-muted-foreground">Registration Fee</div>
                  <div className="text-2xl font-bold text-primary" data-testid="text-registration-fee">$11</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Upfront Payment</div>
                  <div className="text-2xl font-bold text-secondary" data-testid="text-upfront-amount">
                    ${pricing.upfront.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">After Placement</div>
                  <div className="text-2xl font-bold text-accent" data-testid="text-after-placement">
                    ${pricing.afterPlacement.toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="text-center mt-4">
                <div className="text-sm text-muted-foreground">Total Program Cost</div>
                <div className="text-3xl font-bold" data-testid="text-total-cost">
                  ${pricing.total.toLocaleString()}
                </div>
                {pricing.discount > 0 && (
                  <div className="text-sm text-accent">
                    You save ${pricing.discount.toLocaleString()}!
                  </div>
                )}
              </div>
            </div>

            <div className="text-center mt-6">
              <Button 
                size="lg" 
                className="px-8 py-4 text-lg animate-pulse-neon"
                onClick={() => window.location.href = '/api/login'}
                data-testid="button-start-registration"
              >
                Start with $11 Registration
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* Starter Plan */}
          <Card className="glass-card relative">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">Starter Plan</h3>
                <div className="text-4xl font-bold text-primary mb-2">$199</div>
                <div className="text-muted-foreground">Upfront + $5,789 after placement</div>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Full curriculum access
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  1-on-1 mentorship
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Job placement support
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Lifetime community access
                </li>
              </ul>
              <Button 
                variant="outline" 
                className="w-full"
                data-testid="button-choose-starter"
              >
                Choose Plan
              </Button>
            </CardContent>
          </Card>

          {/* Professional Plan */}
          <Card className="glass-card relative border-2 border-primary">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-primary text-primary-foreground px-4 py-2">
                Most Popular
              </Badge>
            </div>
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">Professional Plan</h3>
                <div className="text-4xl font-bold text-primary mb-2">$499</div>
                <div className="text-muted-foreground">Upfront + $5,489 after placement</div>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Everything in Starter
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Priority job placement
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Resume & LinkedIn optimization
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Interview coaching
                </li>
              </ul>
              <Button 
                className="w-full animate-pulse-neon"
                data-testid="button-choose-professional"
              >
                Choose Plan
              </Button>
            </CardContent>
          </Card>

          {/* Full Upfront Plan */}
          <Card className="glass-card relative">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">Full Upfront</h3>
                <div className="text-4xl font-bold text-accent mb-2">$4,799</div>
                <div className="text-muted-foreground">20% Discount - Pay Once</div>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Everything in Professional
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Immediate full access
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  VIP support channel
                </li>
                <li className="flex items-center">
                  <Check className="text-accent mr-2 h-4 w-4" />
                  Exclusive networking events
                </li>
              </ul>
              <Button 
                variant="outline" 
                className="w-full bg-accent/20 border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                data-testid="button-choose-full-upfront"
              >
                Choose Plan
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
