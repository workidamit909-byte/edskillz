import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Play, X, Users, TrendingUp, Award, Target } from "lucide-react";

interface DemoVideoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DemoVideoModal({ isOpen, onClose }: DemoVideoModalProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const demoSteps = [
    {
      title: "AI-Powered Career Assessment",
      description: "Our advanced AI analyzes your background, skills, and career goals to create a personalized learning path.",
      icon: Target,
      content: (
        <div className="bg-gradient-to-br from-primary/20 to-secondary/20 p-6 rounded-lg border border-primary/30">
          <div className="flex items-center mb-4">
            <Target className="text-primary mr-2 h-6 w-6" />
            <h4 className="text-lg font-semibold">Personalized Assessment</h4>
          </div>
          <div className="space-y-3 text-sm">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
              <span>Skill gap analysis using AI algorithms</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-secondary rounded-full mr-3"></div>
              <span>Market demand analysis for your target role</span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-accent rounded-full mr-3"></div>
              <span>Customized learning roadmap generation</span>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Interactive Learning Experience",
      description: "Engage with real-world projects, live coding sessions, and hands-on labs that mirror industry scenarios.",
      icon: Play,
      content: (
        <div className="bg-gradient-to-br from-secondary/20 to-accent/20 p-6 rounded-lg border border-secondary/30">
          <div className="flex items-center mb-4">
            <Play className="text-secondary mr-2 h-6 w-6" />
            <h4 className="text-lg font-semibold">Immersive Learning</h4>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <div className="font-medium text-secondary">Real Projects:</div>
              <ul className="space-y-1 text-muted-foreground">
                <li>• Build ML models for Netflix</li>
                <li>• Create dashboards for Uber</li>
                <li>• Design AI systems for healthcare</li>
              </ul>
            </div>
            <div className="space-y-2">
              <div className="font-medium text-accent">Live Support:</div>
              <ul className="space-y-1 text-muted-foreground">
                <li>• 24/7 mentor availability</li>
                <li>• Weekly 1-on-1 sessions</li>
                <li>• Peer collaboration groups</li>
              </ul>
            </div>
          </div>
        </div>
      )
    },
    {
      title: "Industry Connections & Job Placement",
      description: "Leverage our network of 180+ partner companies and dedicated career services for guaranteed placement.",
      icon: Users,
      content: (
        <div className="bg-gradient-to-br from-accent/20 to-primary/20 p-6 rounded-lg border border-accent/30">
          <div className="flex items-center mb-4">
            <Users className="text-accent mr-2 h-6 w-6" />
            <h4 className="text-lg font-semibold">Career Acceleration</h4>
          </div>
          <div className="grid grid-cols-3 gap-4 text-center mb-4">
            <div>
              <div className="text-2xl font-bold text-primary">180+</div>
              <div className="text-xs text-muted-foreground">Partner Companies</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-secondary">94%</div>
              <div className="text-xs text-muted-foreground">Placement Rate</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-accent">$127K</div>
              <div className="text-xs text-muted-foreground">Avg. Salary</div>
            </div>
          </div>
          <div className="flex justify-center space-x-4">
            <img src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face" alt="Google" className="w-8 h-8 rounded-full" />
            <img src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face" alt="Microsoft" className="w-8 h-8 rounded-full" />
            <img src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face" alt="Amazon" className="w-8 h-8 rounded-full" />
            <img src="https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face" alt="Netflix" className="w-8 h-8 rounded-full" />
          </div>
        </div>
      )
    },
    {
      title: "Success & Growth Tracking",
      description: "Monitor your progress with detailed analytics and celebrate milestones as you advance your career.",
      icon: TrendingUp,
      content: (
        <div className="bg-gradient-to-br from-primary/20 via-secondary/20 to-accent/20 p-6 rounded-lg border border-primary/30">
          <div className="flex items-center mb-4">
            <TrendingUp className="text-primary mr-2 h-6 w-6" />
            <h4 className="text-lg font-semibold">Your Success Journey</h4>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-background/50 rounded-lg">
              <div className="flex items-center">
                <Award className="text-accent mr-3 h-5 w-5" />
                <div>
                  <div className="font-medium">Course Completion</div>
                  <div className="text-xs text-muted-foreground">Track learning milestones</div>
                </div>
              </div>
              <div className="text-2xl font-bold text-accent">87%</div>
            </div>
            <div className="flex items-center justify-between p-3 bg-background/50 rounded-lg">
              <div className="flex items-center">
                <TrendingUp className="text-secondary mr-3 h-5 w-5" />
                <div>
                  <div className="font-medium">Skill Development</div>
                  <div className="text-xs text-muted-foreground">Real-time progress updates</div>
                </div>
              </div>
              <div className="text-2xl font-bold text-secondary">+45%</div>
            </div>
            <div className="text-center">
              <Button size="sm" className="animate-pulse-neon">
                View Your Dashboard
              </Button>
            </div>
          </div>
        </div>
      )
    }
  ];

  const nextStep = () => {
    setCurrentStep((prev) => (prev + 1) % demoSteps.length);
  };

  const prevStep = () => {
    setCurrentStep((prev) => (prev - 1 + demoSteps.length) % demoSteps.length);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center mb-4">
            <span className="bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent">
              How AI & Skills Transform Your Career
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Current Step Display */}
          <div className="text-center">
            <div className="inline-flex items-center space-x-2 bg-muted/50 px-4 py-2 rounded-full mb-4">
              {(() => {
                const IconComponent = demoSteps[currentStep].icon;
                return <IconComponent className="h-5 w-5 text-primary" />;
              })()}
              <span className="text-sm font-medium">
                Step {currentStep + 1} of {demoSteps.length}
              </span>
            </div>
            <h3 className="text-xl font-bold mb-2">{demoSteps[currentStep].title}</h3>
            <p className="text-muted-foreground mb-6">{demoSteps[currentStep].description}</p>
          </div>

          {/* Step Content */}
          <div className="min-h-[300px] flex items-center justify-center">
            {demoSteps[currentStep].content}
          </div>

          {/* Navigation Controls */}
          <div className="flex justify-between items-center">
            <Button variant="outline" onClick={prevStep} disabled={currentStep === 0}>
              Previous
            </Button>
            
            {/* Progress Indicators */}
            <div className="flex space-x-2">
              {demoSteps.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentStep(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentStep ? 'bg-primary' : 'bg-muted'
                  }`}
                />
              ))}
            </div>
            
            {currentStep === demoSteps.length - 1 ? (
              <Button 
                onClick={() => {
                  window.location.href = '/api/login';
                  onClose();
                }}
                className="animate-pulse-neon"
              >
                Start Your Journey
              </Button>
            ) : (
              <Button onClick={nextStep} className="bg-primary hover:bg-primary/90">
                Next
              </Button>
            )}
          </div>

          {/* Call to Action */}
          {currentStep === demoSteps.length - 1 && (
            <div className="text-center border-t pt-6 mt-6">
              <p className="text-sm text-muted-foreground mb-4">
                Join thousands of successful graduates who transformed their careers with AI and Data Science
              </p>
              <div className="flex justify-center space-x-4">
                <Button variant="outline" onClick={onClose}>
                  Learn More
                </Button>
                <Button 
                  onClick={() => {
                    window.location.href = '/api/login';
                    onClose();
                  }}
                  className="animate-pulse-neon"
                >
                  Register Now - Only $11
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}