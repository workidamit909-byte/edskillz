import {
  users,
  courses,
  enrollments,
  resumes,
  successStories,
  jobListings,
  contactSubmissions,
  type User,
  type UpsertUser,
  type Course,
  type InsertCourse,
  type Enrollment,
  type InsertEnrollment,
  type Resume,
  type InsertResume,
  type SuccessStory,
  type InsertSuccessStory,
  type JobListing,
  type InsertJobListing,
  type ContactSubmission,
  type InsertContactSubmission,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Course operations
  getCourses(): Promise<Course[]>;
  getCourse(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Enrollment operations
  getEnrollmentsByUser(userId: string): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollmentProgress(id: string, progress: number): Promise<void>;
  
  // Resume operations
  getResumesByUser(userId: string): Promise<Resume[]>;
  createResume(resume: InsertResume): Promise<Resume>;
  
  // Success stories
  getSuccessStories(): Promise<SuccessStory[]>;
  getFeaturedSuccessStories(): Promise<SuccessStory[]>;
  createSuccessStory(story: InsertSuccessStory): Promise<SuccessStory>;
  
  // Job listings
  getActiveJobListings(): Promise<JobListing[]>;
  createJobListing(job: InsertJobListing): Promise<JobListing>;
  
  // Contact submissions
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Course operations
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCourse(id: string): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(courseData: InsertCourse): Promise<Course> {
    const [course] = await db.insert(courses).values(courseData).returning();
    return course;
  }

  // Enrollment operations
  async getEnrollmentsByUser(userId: string): Promise<Enrollment[]> {
    return await db.select().from(enrollments).where(eq(enrollments.userId, userId));
  }

  async createEnrollment(enrollmentData: InsertEnrollment): Promise<Enrollment> {
    const [enrollment] = await db.insert(enrollments).values(enrollmentData).returning();
    return enrollment;
  }

  async updateEnrollmentProgress(id: string, progress: number): Promise<void> {
    await db.update(enrollments)
      .set({ progress })
      .where(eq(enrollments.id, id));
  }

  // Resume operations
  async getResumesByUser(userId: string): Promise<Resume[]> {
    return await db.select().from(resumes).where(eq(resumes.userId, userId)).orderBy(desc(resumes.uploadedAt));
  }

  async createResume(resumeData: InsertResume): Promise<Resume> {
    const [resume] = await db.insert(resumes).values(resumeData).returning();
    return resume;
  }

  // Success stories
  async getSuccessStories(): Promise<SuccessStory[]> {
    return await db.select().from(successStories).orderBy(desc(successStories.createdAt));
  }

  async getFeaturedSuccessStories(): Promise<SuccessStory[]> {
    return await db.select().from(successStories).where(eq(successStories.featured, true)).orderBy(desc(successStories.createdAt));
  }

  async createSuccessStory(storyData: InsertSuccessStory): Promise<SuccessStory> {
    const [story] = await db.insert(successStories).values(storyData).returning();
    return story;
  }

  // Job listings
  async getActiveJobListings(): Promise<JobListing[]> {
    return await db.select().from(jobListings).where(eq(jobListings.active, true)).orderBy(desc(jobListings.createdAt));
  }

  async createJobListing(jobData: InsertJobListing): Promise<JobListing> {
    const [job] = await db.insert(jobListings).values(jobData).returning();
    return job;
  }

  // Contact submissions
  async createContactSubmission(submissionData: InsertContactSubmission): Promise<ContactSubmission> {
    const [submission] = await db.insert(contactSubmissions).values(submissionData).returning();
    return submission;
  }
}

export const storage = new DatabaseStorage();
